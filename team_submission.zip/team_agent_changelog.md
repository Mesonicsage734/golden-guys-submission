# Changelog: agent.py optimization pass

Applied to a copy of the team's own `agent.py`, verified against the official starter
harness (`aichessathon-starter`), never touching the original file or the team's repo
directly. All numbers below were measured, not estimated.

## What the engine's strategy actually is (unchanged)

Same "brain" as before, at every stage: an opening book (polyglot format, first 10 plies,
currently 0 entries — no `book.bin` shipped), a Syzygy tablebase probe (currently `None` —
no tables shipped), then iterative-deepening negamax/alpha-beta with a transposition
table, quiescence search, and MVV-LVA move ordering, falling back to `_evaluate` = material
+ piece-square tables. Nothing about *how it judges a position* changed.

## What changed: it applies that same brain deeper, faster, and more carefully

1. **It will stop handing away winning positions by repetition.** The standout finding:
   `_position_counts` (real-game position history) was collected in `_remember()` but never
   read by the search — your own comment said so: *"Nothing reads it yet -- later commits
   wire it into move selection."* `_negamax` and `_quiescence` now check it (combined with a
   new search-local `path_counts`) and score a position that's about to occur for the third
   time as a draw, instead of searching past it as if nothing were wrong. Also added: a
   50-move-rule check (`halfmove_clock >= 100`), which had the same gap.
2. **It sees further ahead in the same clock budget.** Added null-move pruning (skipped
   when in check, near the horizon, right after another null move, or when the side to
   move holds only pawns and a king — the zugzwang shape that would make it actively
   wrong) and late move reductions for quiet, late-ordered, non-check moves.
3. **It tries its best quiet moves first.** Added a killer-move table (two per ply) and a
   history heuristic (keyed by colour/from/to, weighted by `depth²` on a cutoff), both
   feeding into `_order_moves` — but only ever reordering *among* quiet moves; every real
   capture still outranks every quiet move exactly as it did before (verified: the worst
   MVV-LVA capture score is 1.0, killers/history are bounded to [-1.0, -0.6], so the
   ordering invariant can't be violated by the new terms).
4. **It stops burning the whole clock once it's already found a forced mate.** Previously
   `_choose_move`'s iterative-deepening loop had no early exit — it kept re-searching
   deeper even after proving mate, using the full per-move time budget on a result that was
   already certain, at the expense of a later, harder move.
5. **`_evaluate` is faster** (measured 54,715 calls/s -> see below), from precomputed flat
   material+PST tables instead of a dict lookup, a division, and an addition per piece per
   call. This is a pure speed change, verified bit-identical to the original across 1,200
   positions from 30 random games before being made the real path.
6. **Internal search hashing switched from `chess.polyglot.zobrist_hash` to
   `board._transposition_key()`** for the transposition table and the new repetition
   checks — 25x faster (measured), and it's what python-chess's own repetition detection
   is built on. The opening book still uses `zobrist_hash`, since that's required for the
   portable polyglot book format and is a separate, already-correct use.
7. **Fixed a structural double move-generation.** `_negamax` used to build the full legal
   move list *before* checking `depth <= 0`, then discard it entirely and have
   `_quiescence` build its own from scratch. Confirmed via instrumented profiling: 85.7% of
   all `_negamax` calls in a representative 3-second search are at `depth <= 0`, and the
   discarded list-building cost ~9.3% of total search time on its own.
8. **Bonus fix (found by the test suite, not part of the original ask):** `get_move`
   crashed with an unhandled `IndexError` if ever called on an already-terminal position
   (checkmate/stalemate) — the except-fallback (`random.choice(list(board.legal_moves))`)
   had nothing to choose from either. Confirmed this pre-exists in the original file too.
   The referee should never call `get_move` after the game has ended, so this was never a
   real practical risk, but it directly broke the file's own documented promise ("any
   exception falls back to any legal move"), so it's now guarded with one line.
9. **Critical fix, found only by testing the finished changes against real games, not part
   of the original 7-item plan:** `_search_root` discarded its *entire* iterative-deepening
   pass the instant the clock interrupted it partway through — by design, per its own
   comment ("an incomplete pass is discarded entirely rather than trusted"). Combined with
   `_choose_move`'s pre-search move order (`random.shuffle`, then a stable sort where every
   quiet move with no killer/history hit ties at the same score and keeps the shuffle's
   order), this meant: if not even one depth-1 pass finished before time ran out,
   the move actually played had **never been evaluated by anything** — a coin flip among
   legal moves. Reproduced exactly: a forced RNG seed shuffled a real blunder (a knight
   move abandoning the only defender of a mate square) to the front of the list, and with
   the clock already spent, `_choose_move` returned it untested. This is a pre-existing
   fragility in the original file, but items 1-7 above made it measurably more likely to
   trigger, since every node now does more work, so the same tiny time budget more often
   runs out before even one pass completes — this is exactly what an early, buggy arena
   comparison caught (a 50% score against the team's own unmodified original, before this
   fix). `_search_root` now returns whatever it *did* manage to fully score before an
   interruption instead of discarding it; `_choose_move` still always prefers a fully
   completed pass over a partial one, and only falls back to the partial result when
   nothing has completed yet. Confirmed fixed against the exact adversarial case, and the
   full correctness suite still passes 10/10 after this change.

## What was deliberately NOT changed

- **A "PV node" null-move guard was considered and dropped.** Standard engines skip
  null-move pruning on principal-variation nodes, detected by a window of literal width 1
  (`beta == alpha + 1`) — but that check assumes centipawn-scale scoring. This file scores
  in whole pawns, where a width-1 window is enormous, not narrow. Porting the check without
  rescaling it would have silently mis-gated null-move rather than protect anything, so it
  was left out rather than shipped miscalibrated.
- **A malformed-FEN input test was dropped, not fixed.** `get_move` also crashes on
  `chess.Board("not a fen")` — but `fen` is generated by the platform's own referee from
  the wire protocol, never arbitrary or adversarial text, so this isn't a reachable
  scenario the way the terminal-position case is. Coding around it would add complexity
  against a contract violation that structurally can't happen.
- **Full PVS (principal variation search)** across the whole move loop, deeper
  reverse-futility/static-null-move pruning, and check extensions were not added — out of
  scope for this pass; noted as further headroom if there's time before the deadline.
- **The opening book and tablebase architecture themselves are sound and untouched** — they
  just have no data shipped alongside `agent.py` yet (`book.bin`, `syzygy/`). That's a
  separate, orthogonal opportunity: shipping either would give free strength (book moves
  are instant and theory-correct; tablebase moves are provably perfect) without touching
  any of the search code above.

## Measured evidence

### Confirmed via static analysis + instrumented profiling (before any fix)
- `_evaluate`: 54,715 calls/s (18.28us/call)
- `chess.polyglot.zobrist_hash`: 41,280 calls/s vs `board._transposition_key()`:
  1,046,063 calls/s (~25x)
- `list(board.legal_moves)`: 54.44us/call; 85.7% of all `_negamax` calls in a real 3-second
  search are at `depth <= 0`, where that list was generated and then discarded
- Confirmed with a verified mate-in-1 position: the original code used the full 5.00s of a
  5-second budget even after finding the mate

### Correctness (10/10 test groups passing)
Eval colour symmetry, board-state integrity after search (including a forced mid-search
timeout), mate-in-one (self-verified against `python-chess`, not hardcoded), mate-score
early stop, takes-free-material tactics, repetition awareness (a position pre-seeded as
"already seen twice" now scores as a draw, not as a winning position), terminal positions,
unusual-but-valid positions, near-zero clock, and a legality stress test across random
playouts.

### Strength, through the real referee (`python -m harness.arena`)

| Opponent | Games | Result | Score | Terminations |
|---|---|---|---|---|
| `baselines/minimax` | 16 | +11 =4 -1 | **81.2%** | checkmate 12, threefold 4 |
| Team's own unmodified original `agent.py` | 16 | +10 =6 **-0** | **81.2%** | checkmate 10, threefold 6 |

The head-to-head result is the one that matters most: **10 wins, 6 draws, zero losses**
against the exact engine you deployed today, 10s+0.1s, alternating colours. All draws were
by threefold repetition, not by either side actually failing — none of the failure
terminations (crash/illegal/flag) occurred in either match.

One honest caveat: an early version of this comparison (before item 9 above was found and
fixed) gave a misleading ~50% score in both matches purely from run-to-run randomness in an
unseeded `random.shuffle()`, and a separate mistake on my part (re-testing a stale copy of
the file that didn't actually have the fix) produced a second, also-invalid intermediate
number. The 81.2%/81.2% figures above are from the corrected, verified, in-sync file. Given
the file's own move-order randomness, treat any individual small-sample score (including
this one) as a directional signal, not an exact number — running more games, or at the real
120s+0.5s competition time control specifically, would narrow the true margin further.

## Files
- `agent.py` — the fixed engine, ready to drop into the team repo in place of the current one
- `test_engine.py` — the correctness suite, adapted from the one built for a separate
  engine earlier this week; run before every future change
